"use client";

import { useState, useEffect } from "react";
import { Plus, Trash2, Loader2, Zap, Play } from "lucide-react";
import { toast } from "sonner";

export default function KeywordPoolsPage() {
  const [pools, setPools] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState("");
  const [keywordsText, setKeywordsText] = useState("");
  const [category, setCategory] = useState("");
  const [running, setRunning] = useState(false);

  const loadPools = () => {
    setLoading(true);
    fetch("/api/admin/keyword-pools")
      .then(r => r.json())
      .then(d => { setPools(d.pools || []); setLoading(false); });
  };

  useEffect(() => { loadPools(); }, []);

  const handleCreate = async () => {
    const keywords = keywordsText.split("\n").map(k => k.trim()).filter(Boolean);
    if (!name || keywords.length < 2) return toast.error("نام گروه و حداقل ۲ کلیدواژه لازم است");

    await fetch("/api/admin/keyword-pools", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, keywords, category }),
    });

    setName(""); setKeywordsText(""); setCategory("");
    toast.success("گروه ساخته شد");
    loadPools();
  };

  const handleDelete = async (id: string) => {
    await fetch("/api/admin/keyword-pools", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });
    loadPools();
  };

  const handleRunNow = async () => {
    setRunning(true);
    const res = await fetch("/api/cron/auto-blog", {
      headers: { Authorization: `Bearer ${process.env.NEXT_PUBLIC_CRON_SECRET || ""}` },
    });
    const data = await res.json();
    data.success ? toast.success(`✅ ${data.wordCount} کلمه - ${data.poolName}`) : toast.error(data.error || "خطا");
    setRunning(false);
    loadPools();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-black text-stone-900">گروه‌های کلیدواژه</h1>
        <button onClick={handleRunNow} disabled={running}
          className="px-4 py-2 bg-emerald-500 text-white rounded-xl text-sm font-bold flex items-center gap-2 disabled:opacity-50">
          {running ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
          اجرای دستی
        </button>
      </div>

      {/* Create */}
      <div className="bg-white rounded-xl border p-4 mb-6 space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <input value={name} onChange={e => setName(e.target.value)}
            placeholder="اسم گروه (مثلاً: آموزشگاه‌های آیلتس شیراز)"
            className="px-3 py-2 border rounded-lg text-sm outline-none focus:border-amber-300" />
          <input value={category} onChange={e => setCategory(e.target.value)}
            placeholder="دسته‌بندی (مثلاً: آیلتس)"
            className="px-3 py-2 border rounded-lg text-sm outline-none focus:border-amber-300" />
        </div>
        <textarea value={keywordsText} onChange={e => setKeywordsText(e.target.value)}
          placeholder={`کلیدواژه‌ها (هر خط یکی):\nآموزشگاه آیلتس\nگاما\nشیراز\nقیمت\nآدرس`}
          rows={8}
          className="w-full px-3 py-2 border rounded-lg text-sm outline-none focus:border-amber-300 resize-none font-mono" dir="ltr" />
        <button onClick={handleCreate}
          className="w-full py-2 bg-amber-500 text-white rounded-xl text-sm font-bold flex items-center justify-center gap-2">
          <Plus className="w-4 h-4" /> ایجاد گروه کلیدواژه
        </button>
      </div>

      {/* List */}
      {loading ? (
        <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin" /></div>
      ) : (
        <div className="space-y-3">
          {pools.map(pool => (
            <div key={pool.id} className="bg-white rounded-xl border p-4">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="text-sm font-bold text-stone-900">{pool.name}</h3>
                  <span className="text-[10px] text-stone-400">{pool.keywords.length} کلیدواژه | {pool.category || "بدون دسته"}</span>
                </div>
                <button onClick={() => handleDelete(pool.id)}
                  className="p-1.5 rounded-lg text-stone-400 hover:text-red-500 hover:bg-red-50">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {pool.keywords.map((kw: string) => (
                  <span key={kw} className="text-[11px] bg-amber-50 text-amber-700 px-2.5 py-1 rounded-full border border-amber-200 font-medium">
                    {kw}
                  </span>
                ))}
              </div>
            </div>
          ))}
          {pools.length === 0 && (
            <div className="text-center py-16 text-stone-400">
              <Zap className="w-10 h-10 mx-auto mb-3 opacity-50" />
              <p>هیچ گروهی نساختی. یه گروه بساز تا سیستم خودکار مقاله تولید کنه.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}