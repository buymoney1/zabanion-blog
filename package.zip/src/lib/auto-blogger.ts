import { prisma } from "@/lib/prisma";
import { generateResearchedArticle } from "./ai-content-generator";
import { generateSEOMetadata } from "./ai";

interface AutoBlogResult {
  success: boolean;
  article?: any;
  error?: string;
  poolName: string;
  keywords: string[];
  wordCount: number;
  passedValidation: boolean;
  validationErrors: string[];
}

function validateArticle(content: string, title: string): { passed: boolean; errors: string[] } {
  const errors: string[] = [];
  const plainText = content.replace(/<[^>]*>/g, "").trim();
  const wordCount = plainText.split(/\s+/).filter(Boolean).length;

  if (wordCount < 500) {
    errors.push(`کلمات: ${wordCount} (حداقل ۵۰۰)`);
  }
  if (!title || title.length < 10) {
    errors.push("عنوان کوتاه است");
  }
  const h2Count = (content.match(/<h2[^>]*>/gi) || []).length;
  if (h2Count < 2) {
    errors.push(`Heading: ${h2Count} (حداقل ۲)`);
  }
  const pCount = (content.match(/<p[^>]*>/gi) || []).length;
  if (pCount < 3) {
    errors.push(`پاراگراف: ${pCount} (حداقل ۳)`);
  }
  if (/آموزشگاه الف|آموزشگاه ب|آموزشگاه ج/i.test(content)) {
    errors.push("اسم ساختگی دارد");
  }

  return { passed: errors.length === 0, errors };
}

export async function autoGenerateAndPublish(): Promise<AutoBlogResult> {
  console.log("\n🤖 AUTO BLOGGER\n");

  try {
    // Step 1: Get all active pools
    const pools = await prisma.keywordPool.findMany({
      where: { isActive: true },
    });

    if (pools.length === 0) {
      return {
        success: false,
        error: "هیچ استخر کلیدواژه فعالی نیست",
        poolName: "",
        keywords: [],
        wordCount: 0,
        passedValidation: false,
        validationErrors: ["No pools"],
      };
    }

    // Step 2: Pick random pool (کل گروه رو برمی‌داره)
    const pool = pools[Math.floor(Math.random() * pools.length)];
    const keywords = pool.keywords; // ⭐ همه کلیدواژه‌های این گروه
    
    console.log(`📦 گروه: "${pool.name}" | ${keywords.length} کلیدواژه`);
    console.log(`🎯 ${keywords.join(" | ")}`);

    // Step 3: Check duplicate (same pool in last 3 days)
    const recentArticle = await prisma.seoArticle.findFirst({
      where: {
        keywords: { hasSome: keywords },
        createdAt: { gte: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000) },
      },
      orderBy: { createdAt: "desc" },
    });

    if (recentArticle) {
      console.log("⏩ موضوع مشابه در ۳ روز اخیر منتشر شده\n");
      return {
        success: false,
        error: "موضوع تکراری",
        poolName: pool.name,
        keywords,
        wordCount: 0,
        passedValidation: false,
        validationErrors: ["Duplicate"],
      };
    }

    // Step 4: Generate with ALL keywords from this pool
    console.log("✍️ Generating...");
    const topic = pool.name; // ⭐ اسم گروه = موضوع مقاله
    const { title, content, metaDescription } = await generateResearchedArticle(
      keywords,
      topic
    );

    // Step 5: Validate
    console.log("🔍 Validating...");
    const validation = validateArticle(content, title);
    const wordCount = content.replace(/<[^>]*>/g, "").split(/\s+/).filter(Boolean).length;

    if (!validation.passed) {
      console.log("❌ Failed:", validation.errors);
      
      await prisma.cronJobLog.create({
        data: {
          jobName: "auto-blogger",
          status: "skipped",
          details: JSON.stringify({ pool: pool.name, keywords, errors: validation.errors, wordCount }),
          startedAt: new Date(),
          completedAt: new Date(),
        },
      });

      return {
        success: false,
        error: "استاندارد نیست",
        poolName: pool.name,
        keywords,
        wordCount,
        passedValidation: false,
        validationErrors: validation.errors,
      };
    }

    // Step 6: SEO
    const seoData = await generateSEOMetadata(title, content, keywords);

    // Step 7: Unique slug
    const baseSlug = seoData.slug || title.toLowerCase().replace(/[^a-z0-9\s-]/g, "").replace(/\s+/g, "-").slice(0, 80);
    let slug = baseSlug || `article-${Date.now().toString(36)}`;
    let counter = 1;
    while (await prisma.seoArticle.findUnique({ where: { slug } })) {
      slug = `${baseSlug}-${counter}`;
      counter++;
    }

    // Step 8: PUBLISH
    console.log("📤 Publishing...");
    const article = await prisma.seoArticle.create({
      data: {
        title: seoData.metaTitle || title,
        slug,
        content,
        excerpt: seoData.excerpt || metaDescription || "",
        metaTitle: seoData.metaTitle || title.slice(0, 60),
        metaDescription: seoData.metaDescription || metaDescription || "",
        ogTitle: seoData.metaTitle || title,
        ogDescription: seoData.metaDescription || "",
        keywords,
        tags: seoData.tags || keywords.slice(0, 5),
        category: seoData.category || pool.category || keywords[0] || "عمومی",
        wordCount,
        readingTime: seoData.readingTime || Math.ceil(wordCount / 200) || 5,
        isPublished: true,
        publishedAt: new Date(),
      },
    });

    // Log
    await prisma.cronJobLog.create({
      data: {
        jobName: "auto-blogger",
        status: "success",
        details: JSON.stringify({ articleId: article.id, slug: article.slug, pool: pool.name, keywords, wordCount }),
        startedAt: new Date(),
        completedAt: new Date(),
      },
    });

    console.log(`✅ Published: ${article.slug} (${wordCount} words)\n`);
    return { success: true, article, poolName: pool.name, keywords, wordCount, passedValidation: true, validationErrors: [] };
  } catch (error: any) {
    console.error("❌", error.message);
    await prisma.cronJobLog.create({
      data: { jobName: "auto-blogger", status: "failed", error: error.message, startedAt: new Date(), completedAt: new Date() },
    });
    return { success: false, error: error.message, poolName: "", keywords: [], wordCount: 0, passedValidation: false, validationErrors: [error.message] };
  }
}