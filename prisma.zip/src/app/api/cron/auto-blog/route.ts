import { NextRequest, NextResponse } from "next/server";
import { autoGenerateAndPublish } from "@/lib/auto-blogger";

export async function GET(req: NextRequest) {
  try {
    // Verify cron secret
    const authHeader = req.headers.get("authorization");
    const cronSecret = process.env.CRON_SECRET || "e06d1c87d03c45f84135c6a366639888";
    
    if (authHeader !== `Bearer ${cronSecret}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    console.log("\n⏰ CRON JOB: Auto Blogger\n");

    const result = await autoGenerateAndPublish();

    return NextResponse.json(result);
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}